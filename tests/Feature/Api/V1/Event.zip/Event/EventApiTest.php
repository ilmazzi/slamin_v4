<?php

use Domain\Event\Models\Event;
use Domain\Event\Models\EventAudienceInvite;
use Domain\Event\Models\EventAvailabilityVote;
use Domain\Event\Models\EventParticipantInvite;
use Domain\Event\Models\EventCategory;
use Domain\Notification\Models\Notification;
use Domain\User\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Laravel\Sanctum\Sanctum;
use App\Mail\EventExternalParticipantInviteMail;

uses(RefreshDatabase::class);

function eventAuthor(): User
{
    return User::factory()->poetOrganizer()->create();
}

it('creates a fixed in person event and stores the recent place', function () {
    $user = eventAuthor();
    Sanctum::actingAs($user);

    $category = EventCategory::query()->create([
        'slug' => 'reading',
        'is_active' => true,
        'sort_order' => 1,
    ]);
    $category->translations()->create([
        'locale' => 'it',
        'name' => 'Reading',
    ]);

    $response = $this->postJson('/api/v1/events', [
        'title' => 'My reading',
        'description' => 'Event body',
        'event_category_id' => $category->id,
        'schedule_mode' => 'fixed',
        'delivery_mode' => 'in_person',
        'status' => 'published',
        'is_public' => true,
        'occurrence' => [
            'starts_at' => now()->addDay()->toISOString(),
            'timezone' => 'Europe/Rome',
        ],
        'venue' => [
            'place_name' => 'Circolo culturale',
            'country_code' => 'IT',
            'city' => 'Roma',
            'postal_code' => '00100',
            'address_line' => 'Via Roma 1',
        ],
    ]);

    $response
        ->assertOk()
        ->assertJsonPath('data.event.slug', 'my-reading')
        ->assertJsonPath('data.event.schedule_mode', 'fixed')
        ->assertJsonPath('data.event.delivery_mode', 'in_person');

    $this->assertDatabaseHas('events', [
        'title' => 'My reading',
        'status' => 'published',
    ]);

    $this->assertDatabaseHas('recent_event_places', [
        'user_id' => $user->id,
        'place_name' => 'Circolo culturale',
        'city' => 'Roma',
    ]);
});

it('notifies internal participant and audience invitees when creating an event', function () {
    $organizer = eventAuthor();
    $participant = eventAuthor();
    $audience = User::factory()->create();
    Sanctum::actingAs($organizer);

    $response = $this->postJson('/api/v1/events', [
        'title' => 'Invite event',
        'description' => 'Event body',
        'schedule_mode' => 'fixed',
        'delivery_mode' => 'online',
        'status' => 'draft',
        'occurrence' => [
            'starts_at' => now()->addDay()->toISOString(),
            'timezone' => 'UTC',
        ],
        'online' => [
            'meeting_url' => 'https://example.com/meet',
            'timezone' => 'UTC',
        ],
        'participant_invites' => [
            [
                'user_id' => $participant->id,
                'role' => 'artist',
                'invite_type' => 'internal',
            ],
        ],
        'audience_invite_user_ids' => [$audience->id],
    ]);

    $response->assertOk();

    $this->assertDatabaseHas('notifications', [
        'user_id' => $participant->id,
        'type' => 'event_participant_invited',
    ]);

    $this->assertDatabaseHas('notifications', [
        'user_id' => $audience->id,
        'type' => 'event_audience_invited',
    ]);
});

it('sends an email to external participant invitees when creating an event', function () {
    Mail::fake();
    $organizer = eventAuthor();
    Sanctum::actingAs($organizer);

    $response = $this->postJson('/api/v1/events', [
        'title' => 'External invite event',
        'description' => 'Event body',
        'schedule_mode' => 'fixed',
        'delivery_mode' => 'online',
        'status' => 'draft',
        'occurrence' => [
            'starts_at' => now()->addDay()->toISOString(),
            'timezone' => 'UTC',
        ],
        'online' => [
            'meeting_url' => 'https://example.com/meet',
            'timezone' => 'UTC',
        ],
        'participant_invites' => [
            [
                'name' => 'Mario Rossi',
                'email' => 'mario@example.com',
                'role' => 'host',
                'invite_type' => 'external',
            ],
        ],
    ]);

    $response->assertOk();

    Mail::assertSent(EventExternalParticipantInviteMail::class, function (EventExternalParticipantInviteMail $mail) {
        return $mail->hasTo('mario@example.com')
            && $mail->event->title === 'External invite event'
            && $mail->invite->role === 'host';
    });

    $this->assertDatabaseHas('event_participant_invites', [
        'email' => 'mario@example.com',
        'invite_type' => 'external',
        'status' => 'sent',
    ]);
});

it('creates an availability based online event', function () {
    Sanctum::actingAs(eventAuthor());

    $response = $this->postJson('/api/v1/events', [
        'title' => 'Online workshop',
        'description' => 'Workshop body',
        'schedule_mode' => 'availability',
        'delivery_mode' => 'online',
        'status' => 'draft',
        'availability_poll' => [
            'response_deadline' => now()->addDays(2)->toISOString(),
            'instructions' => 'Scegli almeno una opzione',
        ],
        'availability_options' => [
            [
                'starts_at' => now()->addDays(3)->toISOString(),
                'timezone' => 'UTC',
            ],
        ],
        'online' => [
            'meeting_url' => 'https://example.com/meet',
            'timezone' => 'UTC',
        ],
    ]);

    $response
        ->assertOk()
        ->assertJsonPath('data.event.schedule_mode', 'availability')
        ->assertJsonPath('data.event.delivery_mode', 'online')
        ->assertJsonPath('data.event.availability_options.0.timezone', 'UTC');
});

it('lists event categories publicly', function () {
    $category = EventCategory::query()->create([
        'slug' => 'poetry-slam',
        'is_active' => true,
        'sort_order' => 1,
    ]);
    $category->translations()->create([
        'locale' => 'it',
        'name' => 'Poetry Slam',
    ]);

    $response = $this->getJson('/api/v1/event-categories');

    $response
        ->assertOk()
        ->assertJsonCount(1, 'data.categories')
        ->assertJsonPath('data.categories.0.slug', 'poetry-slam');
});

it('shows own draft event to the owner', function () {
    $user = eventAuthor();
    Sanctum::actingAs($user);

    $event = Event::query()->create([
        'user_id' => $user->id,
        'title' => 'Private draft event',
        'slug' => 'private-draft-event',
        'description' => 'Body',
        'schedule_mode' => 'fixed',
        'delivery_mode' => 'online',
        'language' => 'it',
        'status' => 'draft',
        'is_public' => false,
    ]);

    $response = $this->getJson("/api/v1/events/{$event->slug}");

    $response
        ->assertOk()
        ->assertJsonPath('data.event.slug', 'private-draft-event')
        ->assertJsonPath('data.event.status', 'draft');
});

it('allows invited users to list and respond to event invites', function () {
    $organizer = eventAuthor();
    $participant = eventAuthor();
    $audience = User::factory()->create();

    $event = Event::query()->create([
        'user_id' => $organizer->id,
        'title' => 'Response event',
        'slug' => 'response-event',
        'description' => 'Body',
        'schedule_mode' => 'fixed',
        'delivery_mode' => 'online',
        'language' => 'it',
        'status' => 'published',
        'is_public' => true,
        'published_at' => now(),
    ]);

    $participantInvite = EventParticipantInvite::query()->create([
        'event_id' => $event->id,
        'user_id' => $participant->id,
        'role' => 'artist',
        'invite_type' => 'internal',
        'status' => 'pending',
    ]);

    $audienceInvite = EventAudienceInvite::query()->create([
        'event_id' => $event->id,
        'user_id' => $audience->id,
        'status' => 'pending',
    ]);

    Sanctum::actingAs($participant);

    $this->getJson('/api/v1/my/event-participant-invites')
        ->assertOk()
        ->assertJsonCount(1, 'data.invites')
        ->assertJsonPath('data.invites.0.id', $participantInvite->id);

    $this->patchJson("/api/v1/event-participant-invites/{$participantInvite->id}/respond", [
        'status' => 'accepted',
    ])
        ->assertOk()
        ->assertJsonPath('data.invite.status', 'accepted');

    Sanctum::actingAs($audience);

    $this->getJson('/api/v1/my/event-audience-invites')
        ->assertOk()
        ->assertJsonCount(1, 'data.invites')
        ->assertJsonPath('data.invites.0.id', $audienceInvite->id);

    $this->patchJson("/api/v1/event-audience-invites/{$audienceInvite->id}/respond", [
        'status' => 'declined',
    ])
        ->assertOk()
        ->assertJsonPath('data.invite.status', 'declined');

    $this->assertDatabaseHas('notifications', [
        'user_id' => $organizer->id,
        'type' => 'event_participant_invite_response',
    ]);

    $this->assertDatabaseHas('notifications', [
        'user_id' => $organizer->id,
        'type' => 'event_audience_invite_response',
    ]);
});

it('allows invited users to vote and unvote on availability options', function () {
    $organizer = eventAuthor();
    $participant = eventAuthor();

    $event = Event::query()->create([
        'user_id' => $organizer->id,
        'title' => 'Availability voting event',
        'slug' => 'availability-voting-event',
        'description' => 'Body',
        'schedule_mode' => 'availability',
        'delivery_mode' => 'online',
        'language' => 'it',
        'status' => 'draft',
        'is_public' => false,
    ]);

    $event->availabilityPoll()->create([
        'response_deadline' => now()->addDay(),
        'instructions' => 'Vote now',
    ]);

    $option = $event->availabilityOptions()->create([
        'starts_at' => now()->addDays(2),
        'timezone' => 'Europe/Rome',
    ]);

    EventParticipantInvite::query()->create([
        'event_id' => $event->id,
        'user_id' => $participant->id,
        'role' => 'artist',
        'invite_type' => 'internal',
        'status' => 'pending',
    ]);

    Sanctum::actingAs($participant);

    $this->postJson("/api/v1/events/{$event->id}/availability-options/{$option->id}/vote")
        ->assertOk()
        ->assertJsonPath('data.event.availability_options.0.votes_count', 1)
        ->assertJsonPath('data.event.availability_options.0.current_user_has_voted', true);

    $this->assertDatabaseHas('event_availability_votes', [
        'event_availability_option_id' => $option->id,
        'user_id' => $participant->id,
    ]);

    $this->deleteJson("/api/v1/events/{$event->id}/availability-options/{$option->id}/vote")
        ->assertOk()
        ->assertJsonPath('data.event.availability_options.0.votes_count', 0)
        ->assertJsonPath('data.event.availability_options.0.current_user_has_voted', false);

    $this->assertDatabaseMissing('event_availability_votes', [
        'event_availability_option_id' => $option->id,
        'user_id' => $participant->id,
    ]);
});

it('allows the organizer to finalize an availability option and create the final occurrence', function () {
    $organizer = eventAuthor();
    $participant = eventAuthor();
    $audience = User::factory()->create();

    $event = Event::query()->create([
        'user_id' => $organizer->id,
        'title' => 'Availability finalized event',
        'slug' => 'availability-finalized-event',
        'description' => 'Body',
        'schedule_mode' => 'availability',
        'delivery_mode' => 'online',
        'language' => 'it',
        'status' => 'published',
        'is_public' => true,
        'published_at' => now(),
    ]);

    $event->availabilityPoll()->create([
        'response_deadline' => now()->addDay(),
        'instructions' => 'Vote now',
    ]);

    $selectedOption = $event->availabilityOptions()->create([
        'starts_at' => now()->addDays(2),
        'ends_at' => now()->addDays(2)->addHours(2),
        'timezone' => 'Europe/Rome',
    ]);

    $event->availabilityOptions()->create([
        'starts_at' => now()->addDays(3),
        'timezone' => 'Europe/Rome',
    ]);

    EventParticipantInvite::query()->create([
        'event_id' => $event->id,
        'user_id' => $participant->id,
        'role' => 'artist',
        'invite_type' => 'internal',
        'status' => 'accepted',
    ]);

    EventAudienceInvite::query()->create([
        'event_id' => $event->id,
        'user_id' => $audience->id,
        'status' => 'accepted',
    ]);

    EventAvailabilityVote::query()->create([
        'event_availability_option_id' => $selectedOption->id,
        'user_id' => $participant->id,
    ]);

    Sanctum::actingAs($organizer);

    $response = $this->postJson("/api/v1/events/{$event->id}/availability-options/{$selectedOption->id}/finalize");

    $response
        ->assertOk()
        ->assertJsonPath('data.event.availability_poll.is_finalized', true)
        ->assertJsonPath('data.event.occurrences.0.timezone', 'Europe/Rome');

    $selectedOptionPayload = collect($response->json('data.event.availability_options'))
        ->firstWhere('id', $selectedOption->id);

    expect($selectedOptionPayload)->not->toBeNull();
    expect($selectedOptionPayload['is_final'])->toBeTrue();

    expect($selectedOption->fresh()->finalized_at)->not->toBeNull();

    $this->assertDatabaseHas('event_occurrences', [
        'event_id' => $event->id,
        'timezone' => 'Europe/Rome',
        'is_primary' => true,
    ]);

    $this->assertDatabaseHas('notifications', [
        'user_id' => $participant->id,
        'type' => 'event_availability_finalized',
    ]);

    $this->assertDatabaseHas('notifications', [
        'user_id' => $audience->id,
        'type' => 'event_availability_finalized',
    ]);
});
